# Yameroo (Fabric 1.21.1) by Mr. Enjou
Requires Java 21, Fabric Loader 0.16+ and Fabric API.

## Build the jar
A) Easiest: push this folder to a GitHub repo, open Actions > build, download the `Yameroo-jar` artifact.
B) Install JDK 21 + Gradle 8.10+, run `gradle build`. Jar: build/libs/yameroo-1.0.0.jar
C) Open in IntelliJ IDEA (Gradle import) and run the `build` task.

## Guide
- Spawn eggs for Raihan, Sahil, Anmol are in the Yameroo creative tab. Anmol also visits the Overworld daily like a wandering trader.
- Raw tobacco leaf > furnace > dried leaf. 2 dried leaves + paper = 3 cigarettes.
- 3 grapes + sugar + glass bottle = Deshi Wine. Grapes grow wild in jungles and plant on dirt, grass or farmland.
- Buy Cat Armour Plating from Anmol, craft 5 into Cat Armour, right-click a cat to equip.
