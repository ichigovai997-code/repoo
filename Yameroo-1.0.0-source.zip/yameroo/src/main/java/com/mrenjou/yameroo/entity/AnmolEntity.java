package com.mrenjou.yameroo.entity;

import com.mrenjou.yameroo.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtCustomerGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.StopFollowingCustomerGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;
import net.minecraft.village.TradedItem;
import net.minecraft.world.World;

import java.util.Optional;

/** Cat lover and trader. Sells cat spawn eggs and the cat armour plating. */
public class AnmolEntity extends MerchantEntity {
    public AnmolEntity(EntityType<? extends AnmolEntity> type, World world) {
        super(type, world);
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.COD));
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return YamerooMob.createAttributes();
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new StopFollowingCustomerGoal(this));
        this.goalSelector.add(2, new LookAtCustomerGoal(this));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.6));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack held = player.getStackInHand(hand);
        if (!held.isOf(Items.VILLAGER_SPAWN_EGG) && this.isAlive() && !this.hasCustomer() && !this.isBaby()) {
            if (!this.getWorld().isClient) {
                this.setCustomer(player);
                this.sendOffers(player, this.getDisplayName(), 1);
            }
            return ActionResult.success(this.getWorld().isClient);
        }
        return super.interactMob(player, hand);
    }

    @Override
    protected void fillRecipes() {
        TradeOfferList offers = this.getOffers();
        // Cat spawn eggs
        offers.add(offer(new TradedItem(Items.DIAMOND, 2), new ItemStack(Items.CAT_SPAWN_EGG), 8));
        offers.add(offer(new TradedItem(Items.GOLD_INGOT, 16), new ItemStack(Items.CAT_SPAWN_EGG), 8));
        offers.add(offer(new TradedItem(Items.NETHERITE_SCRAP, 1), new ItemStack(Items.CAT_SPAWN_EGG), 4));
        // Cat armour plating (only obtainable from Anmol)
        offers.add(offer(new TradedItem(Items.DIAMOND, 1), new ItemStack(ModItems.CAT_ARMOR_PLATING), 16));
        offers.add(offer(new TradedItem(Items.GOLD_INGOT, 10), new ItemStack(ModItems.CAT_ARMOR_PLATING), 16));
        offers.add(offer(new TradedItem(Items.NETHERITE_SCRAP, 1), new ItemStack(ModItems.CAT_ARMOR_PLATING, 2), 8));
    }

    private static TradeOffer offer(TradedItem cost, ItemStack result, int maxUses) {
        return new TradeOffer(cost, Optional.empty(), result, maxUses, 5, 0.05f);
    }

    public void afterUsing(TradeOffer offer) {
    }

    public PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    public SoundEvent getYesSound() {
        return SoundEvents.ENTITY_CAT_PURR;
    }
}
