package com.mrenjou.yameroo.item;

import com.mrenjou.yameroo.Yameroo;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;

/** Right-click a cat to equip it with armour (+8 armour, +4 toughness, +10 max health). */
public class CatArmorItem extends Item {
    private static final Identifier MOD_ID = Yameroo.id("cat_armor");

    public CatArmorItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity user, LivingEntity entity, Hand hand) {
        if (!(entity instanceof CatEntity cat)) return ActionResult.PASS;
        EntityAttributeInstance armor = cat.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        EntityAttributeInstance tough = cat.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        EntityAttributeInstance health = cat.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (armor == null || tough == null || health == null) return ActionResult.PASS;
        if (armor.hasModifier(MOD_ID)) {
            if (!user.getWorld().isClient) user.sendMessage(Text.literal("This cat already wears armour!"), true);
            return ActionResult.FAIL;
        }
        if (!user.getWorld().isClient) {
            armor.addPersistentModifier(new EntityAttributeModifier(MOD_ID, 8.0, EntityAttributeModifier.Operation.ADD_VALUE));
            tough.addPersistentModifier(new EntityAttributeModifier(MOD_ID, 4.0, EntityAttributeModifier.Operation.ADD_VALUE));
            health.addPersistentModifier(new EntityAttributeModifier(MOD_ID, 10.0, EntityAttributeModifier.Operation.ADD_VALUE));
            cat.heal(10.0f);
            cat.playSound(SoundEvents.ENTITY_CAT_PURR, 1.0f, 1.0f);
            stack.decrementUnlessCreative(1, user);
            user.sendMessage(Text.literal("Cat armour equipped!"), true);
        }
        return ActionResult.success(user.getWorld().isClient);
    }
}
