package com.mrenjou.yameroo.registry;

import com.mrenjou.yameroo.Yameroo;
import com.mrenjou.yameroo.block.FourStageCropBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModBlocks {
    public static final Block GRAPE_CROP = Registry.register(Registries.BLOCK, Yameroo.id("grape_crop"),
            new FourStageCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT), () -> ModItems.GRAPES, true));
    public static final Block TOBACCO_CROP = Registry.register(Registries.BLOCK, Yameroo.id("tobacco_crop"),
            new FourStageCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT), () -> ModItems.TOBACCO_SEEDS, false));

    public static void init() {}
}
