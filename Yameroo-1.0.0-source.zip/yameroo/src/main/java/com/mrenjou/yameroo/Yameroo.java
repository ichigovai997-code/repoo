package com.mrenjou.yameroo;

import com.mrenjou.yameroo.registry.ModBlocks;
import com.mrenjou.yameroo.registry.ModEntities;
import com.mrenjou.yameroo.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.SpawnReason;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;

import java.util.List;

public class Yameroo implements ModInitializer {
    public static final String MOD_ID = "yameroo";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModEntities.init();
        ModItems.init();

        // Wild grapes in jungles
        BiomeModifications.addFeature(
                BiomeSelectors.includeByKey(BiomeKeys.JUNGLE, BiomeKeys.SPARSE_JUNGLE, BiomeKeys.BAMBOO_JUNGLE),
                GenerationStep.Feature.VEGETAL_DECORATION,
                RegistryKey.of(RegistryKeys.PLACED_FEATURE, id("grape_patch")));

        // Anmol visits like a wandering trader: once per day, 50% chance, if none exists
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.getRegistryKey() != World.OVERWORLD) return;
            if (world.getTime() % 24000 != 1000) return;
            List<ServerPlayerEntity> players = world.getPlayers();
            if (players.isEmpty() || world.random.nextInt(2) != 0) return;
            if (!world.getEntitiesByType(ModEntities.ANMOL, e -> true).isEmpty()) return;
            ServerPlayerEntity p = players.get(world.random.nextInt(players.size()));
            int x = p.getBlockX() + (world.random.nextBoolean() ? 1 : -1) * (24 + world.random.nextInt(16));
            int z = p.getBlockZ() + (world.random.nextBoolean() ? 1 : -1) * (24 + world.random.nextInt(16));
            if (!world.isChunkLoaded(x >> 4, z >> 4)) return;
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            ModEntities.ANMOL.spawn(world, new BlockPos(x, y, z), SpawnReason.EVENT);
        });
    }
}
