package com.mrenjou.yameroo.entity;

import com.mrenjou.yameroo.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

public class RaihanEntity extends YamerooMob {
    private static final String[] DRUNK = {
            "Hic... who are you? Are you my friend? Hic!",
            "Bhai, ek aur bottle de na...",
            "Duniya ghoom rahi hai ya main?",
            "I'm not drunk, the ground is moving! Hic!",
            "Tu bhi pi ke dekh, Deshi wine best hai!",
            "Cigarette hai kya bhai? Hic.",
            "Yameroo yameroo... hic!",
            "Mujhe kuch nahi hua... *sways*"
    };
    private static final String[] FIGHT = {
            "Oye Sahil, tu gaay se hi baat kar, mujhse nahi!",
            "Chal be, nikal yahan se!",
            "Tere gaay ka doodh bhi pani jaisa hai!",
            "Gaay-chor kahin ka! Hic!",
            "Tujhe toh main dekh lunga!"
    };

    public RaihanEntity(EntityType<? extends RaihanEntity> type, World world) {
        super(type, world);
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.CIGARETTE));
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    @Override
    protected String chatName() { return "Raihan"; }

    @Override
    protected Formatting chatColor() { return Formatting.GOLD; }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.1, true));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.6));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, SahilEntity.class, true));
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (getWorld().isClient) return;
        if (age % 20 == 0 && getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.SMOKE, getX(), getEyeY() - 0.1, getZ(), 2, 0.1, 0.05, 0.1, 0.01);
        }
        // drunk stumbling
        if (age % 30 == 0 && getTarget() == null) {
            addVelocity((random.nextDouble() - 0.5) * 0.2, 0.0, (random.nextDouble() - 0.5) * 0.2);
        }
        if (getTarget() instanceof SahilEntity) {
            if (age % 80 == 0) say(pick(FIGHT));
        } else if (age % 100 == 0 && nearPlayer(6.0)) {
            say(pick(DRUNK));
        }
    }
}
