package com.mrenjou.yameroo.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

public class WineItem extends Item {
    public WineItem(Settings settings) {
        super(settings);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.DRINK;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        ItemStack result = super.finishUsing(stack, world, user);
        if (user instanceof PlayerEntity p) {
            if (!world.isClient) p.sendMessage(Text.literal("Hic! You feel drunk..."), true);
            if (!p.getAbilities().creativeMode) {
                if (result.isEmpty()) return new ItemStack(Items.GLASS_BOTTLE);
                p.getInventory().offerOrDrop(new ItemStack(Items.GLASS_BOTTLE));
            }
        }
        return result;
    }
}
