package com.mrenjou.yameroo.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.PathAwareEntity;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Walk up to the nearest valid entity of a type, then perform an action on it. */
public abstract class ApproachGoal<T extends LivingEntity> extends Goal {
    protected final PathAwareEntity mob;
    private final Class<T> type;
    private final double range;
    protected T target;
    private int cooldown;

    protected ApproachGoal(PathAwareEntity mob, Class<T> type, double range) {
        this.mob = mob;
        this.type = type;
        this.range = range;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    protected abstract boolean valid(T entity);

    protected abstract void act(T entity);

    @Override
    public boolean canStart() {
        if (cooldown > 0) { cooldown--; return false; }
        if (mob.getTarget() != null) return false;
        List<T> list = mob.getWorld().getEntitiesByClass(type, mob.getBoundingBox().expand(range), e -> valid(e));
        target = list.stream().min(Comparator.comparingDouble(e -> mob.squaredDistanceTo(e))).orElse(null);
        return target != null;
    }

    @Override
    public boolean shouldContinue() {
        return target != null && target.isAlive() && mob.getTarget() == null
                && mob.squaredDistanceTo(target) < range * range;
    }

    @Override
    public void tick() {
        mob.getLookControl().lookAt(target);
        if (mob.squaredDistanceTo(target) > 5.0) {
            mob.getNavigation().startMovingTo(target, 1.0);
        } else {
            act(target);
            cooldown = 100 + mob.getRandom().nextInt(100);
            target = null;
        }
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
        target = null;
    }
}
