package com.mrenjou.yameroo;

import com.mrenjou.yameroo.entity.HumanoidRenderer;
import com.mrenjou.yameroo.registry.ModBlocks;
import com.mrenjou.yameroo.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;

public class YamerooClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.RAIHAN,
                ctx -> new HumanoidRenderer<>(ctx, Yameroo.id("textures/entity/raihan.png")));
        EntityRendererRegistry.register(ModEntities.SAHIL,
                ctx -> new HumanoidRenderer<>(ctx, Yameroo.id("textures/entity/sahil.png")));
        EntityRendererRegistry.register(ModEntities.ANMOL,
                ctx -> new HumanoidRenderer<>(ctx, Yameroo.id("textures/entity/anmol.png")));
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.GRAPE_CROP, RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.TOBACCO_CROP, RenderLayer.getCutout());
    }
}
