package com.mrenjou.yameroo.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class SahilEntity extends YamerooMob {
    private static final String[] FIGHT = {
            "Sharabi kahin ka!",
            "Dhuan hata mere cows ke paas se!",
            "Tu apni bottle sambhal, mere cows ko haath mat laga!",
            "Aaja, dekh leta hu tujhe!",
            "Moo-ve out of my way, Raihan!"
    };
    private static final String[] COW = {
            "Come here, my beautiful cow!", "Eat well, little one!", "Moooo! Hahaha!", "Cows are the best!"
    };

    public SahilEntity(EntityType<? extends SahilEntity> type, World world) {
        super(type, world);
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.WHEAT));
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    @Override
    protected String chatName() { return "Sahil"; }

    @Override
    protected Formatting chatColor() { return Formatting.GREEN; }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(1, new MeleeAttackGoal(this, 1.1, true));
        // feed + breed cows
        this.goalSelector.add(3, new ApproachGoal<CowEntity>(this, CowEntity.class, 16.0) {
            @Override
            protected boolean valid(CowEntity cow) {
                return cow.isAlive() && (cow.isBaby() || (cow.getBreedingAge() == 0 && !cow.isInLove()));
            }

            @Override
            protected void act(CowEntity cow) {
                if (cow.isBaby()) cow.growUp(120);
                else cow.setLoveTicks(600);
                if (cow.getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(ParticleTypes.HEART, cow.getX(), cow.getEyeY(), cow.getZ(), 6, 0.3, 0.3, 0.3, 0.0);
                }
                if (mob.getRandom().nextInt(3) == 0) say(pick(COW));
            }
        });
        // scare baby villagers for fun
        this.goalSelector.add(4, new ApproachGoal<VillagerEntity>(this, VillagerEntity.class, 14.0) {
            @Override
            protected boolean valid(VillagerEntity v) {
                return v.isAlive() && v.isBaby();
            }

            @Override
            protected void act(VillagerEntity v) {
                say("Boo! Hahaha!");
                Vec3d away = v.getPos().subtract(mob.getPos()).normalize();
                v.setVelocity(away.x * 0.7, 0.35, away.z * 0.7);
                v.velocityModified = true;
                v.playSound(SoundEvents.ENTITY_VILLAGER_NO, 1.0f, 1.4f);
                if (v.getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(ParticleTypes.ANGRY_VILLAGER, v.getX(), v.getEyeY(), v.getZ(), 5, 0.3, 0.3, 0.3, 0.0);
                }
            }
        });
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, RaihanEntity.class, true));
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (!getWorld().isClient && getTarget() instanceof RaihanEntity && age % 80 == 40) {
            say(pick(FIGHT));
        }
    }
}
