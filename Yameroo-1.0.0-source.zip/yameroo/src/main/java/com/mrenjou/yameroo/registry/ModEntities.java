package com.mrenjou.yameroo.registry;

import com.mrenjou.yameroo.Yameroo;
import com.mrenjou.yameroo.entity.AnmolEntity;
import com.mrenjou.yameroo.entity.RaihanEntity;
import com.mrenjou.yameroo.entity.SahilEntity;
import com.mrenjou.yameroo.entity.YamerooMob;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
    public static final EntityType<RaihanEntity> RAIHAN = register("raihan", RaihanEntity::new);
    public static final EntityType<SahilEntity> SAHIL = register("sahil", SahilEntity::new);
    public static final EntityType<AnmolEntity> ANMOL = register("anmol", AnmolEntity::new);

    private static <T extends PathAwareEntity> EntityType<T> register(String name, EntityType.EntityFactory<T> factory) {
        EntityType<T> type = EntityType.Builder.create(factory, SpawnGroup.CREATURE)
                .dimensions(0.6f, 1.95f).maxTrackingRange(10).build(name);
        return Registry.register(Registries.ENTITY_TYPE, Yameroo.id(name), type);
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(RAIHAN, YamerooMob.createAttributes());
        FabricDefaultAttributeRegistry.register(SAHIL, YamerooMob.createAttributes());
        FabricDefaultAttributeRegistry.register(ANMOL, YamerooMob.createAttributes());
    }
}
