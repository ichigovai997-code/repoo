package com.mrenjou.yameroo.registry;

import com.mrenjou.yameroo.Yameroo;
import com.mrenjou.yameroo.item.CatArmorItem;
import com.mrenjou.yameroo.item.CigaretteItem;
import com.mrenjou.yameroo.item.WineItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AliasedBlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public class ModItems {
    public static final Item GRAPES = reg("grapes", new AliasedBlockItem(ModBlocks.GRAPE_CROP,
            new Item.Settings().food(new FoodComponent.Builder().nutrition(2).saturationModifier(0.3f).build())));
    public static final Item TOBACCO_SEEDS = reg("tobacco_seeds", new AliasedBlockItem(ModBlocks.TOBACCO_CROP, new Item.Settings()));
    public static final Item RAW_TOBACCO_LEAF = reg("raw_tobacco_leaf", new Item(new Item.Settings()));
    public static final Item DRIED_TOBACCO_LEAF = reg("dried_tobacco_leaf", new Item(new Item.Settings()));

    public static final Item CIGARETTE = reg("cigarette", new CigaretteItem(new Item.Settings().food(
            new FoodComponent.Builder().nutrition(0).saturationModifier(0f).alwaysEdible()
                    .statusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 400, 0), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0), 0.5f).build())));

    public static final Item DESHI_WINE = reg("deshi_wine", new WineItem(new Item.Settings().maxCount(16).food(
            new FoodComponent.Builder().nutrition(1).saturationModifier(0.1f).alwaysEdible()
                    .statusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 600, 0), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 400, 0), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 400, 0), 1.0f).build())));

    public static final Item CAT_ARMOR_PLATING = reg("cat_armor_plating", new Item(new Item.Settings()));
    public static final Item CAT_ARMOR = reg("cat_armor", new CatArmorItem(new Item.Settings().maxCount(1)));

    public static final Item RAIHAN_SPAWN_EGG = reg("raihan_spawn_egg",
            new SpawnEggItem(ModEntities.RAIHAN, 0x6b2d2d, 0xd9a066, new Item.Settings()));
    public static final Item SAHIL_SPAWN_EGG = reg("sahil_spawn_egg",
            new SpawnEggItem(ModEntities.SAHIL, 0xf2f2f2, 0x222222, new Item.Settings()));
    public static final Item ANMOL_SPAWN_EGG = reg("anmol_spawn_egg",
            new SpawnEggItem(ModEntities.ANMOL, 0x6a3fa0, 0xe58a2b, new Item.Settings()));

    private static Item reg(String name, Item item) {
        return Registry.register(Registries.ITEM, Yameroo.id(name), item);
    }

    public static void init() {
        ItemGroup group = FabricItemGroup.builder()
                .icon(() -> new ItemStack(DESHI_WINE))
                .displayName(Text.translatable("itemGroup.yameroo"))
                .entries((ctx, e) -> {
                    e.add(GRAPES); e.add(TOBACCO_SEEDS); e.add(RAW_TOBACCO_LEAF); e.add(DRIED_TOBACCO_LEAF);
                    e.add(CIGARETTE); e.add(DESHI_WINE); e.add(CAT_ARMOR_PLATING); e.add(CAT_ARMOR);
                    e.add(RAIHAN_SPAWN_EGG); e.add(SAHIL_SPAWN_EGG); e.add(ANMOL_SPAWN_EGG);
                }).build();
        Registry.register(Registries.ITEM_GROUP, Yameroo.id("main"), group);
    }
}
