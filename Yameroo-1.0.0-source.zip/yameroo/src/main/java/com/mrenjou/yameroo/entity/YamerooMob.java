package com.mrenjou.yameroo.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/** Shared base: 250 HP, passive to players, slowly regenerates, chats to nearby players. */
public abstract class YamerooMob extends PathAwareEntity {
    protected YamerooMob(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 250.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.5);
    }

    protected abstract String chatName();

    protected abstract Formatting chatColor();

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
    }

    /** Sends a chat line to players within 20 blocks. */
    protected void say(String line) {
        for (PlayerEntity p : getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(20), pl -> true)) {
            p.sendMessage(Text.literal("<" + chatName() + "> ").formatted(chatColor())
                    .append(Text.literal(line).formatted(Formatting.WHITE)), false);
        }
    }

    protected String pick(String[] lines) {
        return lines[this.random.nextInt(lines.length)];
    }

    protected boolean nearPlayer(double r) {
        return !getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(r), pl -> true).isEmpty();
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (!getWorld().isClient && age % 100 == 0 && getHealth() < getMaxHealth()) heal(1.0f);
    }

    /** Raihan and Sahil brawl for fun but can never kill each other. */
    @Override
    public boolean damage(DamageSource source, float amount) {
        Entity attacker = source.getAttacker();
        if ((attacker instanceof RaihanEntity || attacker instanceof SahilEntity) && getHealth() - amount < 20.0f) {
            return false;
        }
        return super.damage(source, amount);
    }
}
